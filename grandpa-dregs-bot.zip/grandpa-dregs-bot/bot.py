#!/usr/bin/env python3
"""AI Telegram Bot — full-powered agent with shell, HTTP, code exec, file ops."""

import os
import json
import logging
import sqlite3
import subprocess
import urllib.request
import urllib.parse
from pathlib import Path
from datetime import datetime, timezone

from openai import OpenAI
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# --- Config ---
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "ogw_live_ca8d7717e42b7f665c5c919205b42aa0")
OPENAI_BASE_URL = os.environ.get("OPENAI_BASE_URL", "https://opengateway.gitlawb.com/v1")
MODEL = os.environ.get("MODEL", "mimo-v2.5-pro")
SOUL_PATH = Path(__file__).parent / "soul.md"
DATA_DIR = Path(os.environ.get("DATA_DIR", "/data"))
DB_PATH = DATA_DIR / "memory.db"
WORKSPACE = Path(os.environ.get("WORKSPACE", "/data/workspace"))

# --- Logging ---
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# --- Load soul ---
SYSTEM_PROMPT = SOUL_PATH.read_text() if SOUL_PATH.exists() else "You are a helpful AI assistant."

# --- OpenAI-compatible client ---
client = OpenAI(api_key=OPENAI_API_KEY, base_url=OPENAI_BASE_URL)

# --- Persistent memory ---
MAX_HISTORY = 40


def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS user_profiles (
            chat_id INTEGER PRIMARY KEY,
            username TEXT,
            first_seen TEXT,
            last_seen TEXT,
            notes TEXT
        )
    """)
    conn.commit()
    conn.close()
    logger.info(f"Database initialized at {DB_PATH}")


def get_history(chat_id: int) -> list[dict]:
    conn = sqlite3.connect(str(DB_PATH))
    rows = conn.execute(
        "SELECT role, content FROM conversations WHERE chat_id = ? ORDER BY id DESC LIMIT ?",
        (chat_id, MAX_HISTORY),
    ).fetchall()
    conn.close()
    return [{"role": role, "content": content} for role, content in reversed(rows)]


def add_message(chat_id: int, role: str, content: str, username: str = None):
    conn = sqlite3.connect(str(DB_PATH))
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "INSERT INTO conversations (chat_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
        (chat_id, role, content, now),
    )
    conn.execute(
        """DELETE FROM conversations WHERE chat_id = ? AND id NOT IN (
            SELECT id FROM conversations WHERE chat_id = ? ORDER BY id DESC LIMIT ?
        )""",
        (chat_id, chat_id, MAX_HISTORY),
    )
    if username:
        conn.execute(
            """INSERT INTO user_profiles (chat_id, username, first_seen, last_seen)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(chat_id) DO UPDATE SET last_seen = ?, username = ?""",
            (chat_id, username, now, now, now, username),
        )
    else:
        conn.execute(
            """UPDATE user_profiles SET last_seen = ? WHERE chat_id = ?""",
            (now, chat_id),
        )
    conn.commit()
    conn.close()


def get_user_notes(chat_id: int) -> str:
    conn = sqlite3.connect(str(DB_PATH))
    row = conn.execute(
        "SELECT notes FROM user_profiles WHERE chat_id = ?", (chat_id,)
    ).fetchone()
    conn.close()
    return row[0] if row and row[0] else ""


def save_user_note(chat_id: int, note: str):
    conn = sqlite3.connect(str(DB_PATH))
    existing = conn.execute(
        "SELECT notes FROM user_profiles WHERE chat_id = ?", (chat_id,)
    ).fetchone()
    old_notes = existing[0] if existing and existing[0] else ""
    new_notes = f"{old_notes}\n- {note}".strip() if old_notes else f"- {note}"
    conn.execute(
        """INSERT INTO user_profiles (chat_id, notes) VALUES (?, ?)
           ON CONFLICT(chat_id) DO UPDATE SET notes = ?""",
        (chat_id, new_notes, new_notes),
    )
    conn.commit()
    conn.close()


# ===========================
# TOOLS
# ===========================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "run_shell",
            "description": "Execute ANY shell command. Full system access.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The shell command to execute"}
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_python",
            "description": "Execute Python code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {"type": "string", "description": "Python code to execute"}
                },
                "required": ["code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "http_request",
            "description": "Make an HTTP request. Supports GET, POST, PUT, DELETE with custom headers and body.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "The URL to request"},
                    "method": {"type": "string", "description": "HTTP method", "default": "GET"},
                    "headers": {"type": "object", "description": "HTTP headers"},
                    "body": {"type": "string", "description": "Request body"},
                },
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Search the web using DuckDuckGo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"}
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save_file",
            "description": "Save content to a file in the workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "File path relative to workspace"},
                    "content": {"type": "string", "description": "Content to write"},
                },
                "required": ["filename", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file from the workspace or any path.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "File path to read"}
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files and directories at a path.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path", "default": "."}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "send_file_to_user",
            "description": "Send a file to the user via Telegram.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "Path to the file"},
                    "caption": {"type": "string", "description": "Optional caption"},
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "download_file",
            "description": "Download a file from a URL to the workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "URL to download from"},
                    "filename": {"type": "string", "description": "Filename to save as"},
                },
                "required": ["url", "filename"],
            },
        },
    },
]


def tool_run_shell(command: str) -> str:
    try:
        result = subprocess.run(
            command, shell=True,
            capture_output=True, text=True, timeout=60,
            cwd=str(WORKSPACE),
            env={**os.environ, "HOME": str(WORKSPACE)},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += f"\n[stderr]\n{result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output[:5000] if output else f"[exit code: {result.returncode}] (no output)"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out (60s limit)"
    except Exception as e:
        return f"Shell error: {str(e)}"


def tool_run_python(code: str) -> str:
    try:
        result = subprocess.run(
            ["python3", "-c", code],
            capture_output=True, text=True, timeout=60,
            cwd=str(WORKSPACE),
            env={**os.environ, "HOME": str(WORKSPACE)},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += f"\n[stderr]\n{result.stderr}"
        return output[:5000] if output else "(No output)"
    except subprocess.TimeoutExpired:
        return "Error: Code timed out (60s limit)"
    except Exception as e:
        return f"Python error: {str(e)}"


def tool_http_request(url: str, method: str = "GET", headers: dict = None, body: str = None) -> str:
    try:
        req = urllib.request.Request(url, method=method.upper())
        req.add_header("User-Agent", "AIBot/1.0")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        if body:
            req.data = body.encode("utf-8") if isinstance(body, str) else body
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read(10000).decode("utf-8", errors="replace")
            return f"[HTTP {resp.status}]\n{content[:5000]}"
    except urllib.error.HTTPError as e:
        return f"[HTTP {e.code}] {e.reason}"
    except Exception as e:
        return f"HTTP error: {str(e)}"


def tool_web_search(query: str) -> str:
    try:
        url = f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}&format=json&no_html=1"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBot/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        results = []
        if data.get("AbstractText"):
            results.append(f"**Summary:** {data['AbstractText']}")
        if data.get("AbstractURL"):
            results.append(f"**Source:** {data['AbstractURL']}")
        for topic in data.get("RelatedTopics", [])[:8]:
            if isinstance(topic, dict) and topic.get("Text"):
                results.append(f"• {topic['Text']}")
        return "\n".join(results) if results else f"No results for '{query}'."
    except Exception as e:
        return f"Search error: {str(e)}"


def tool_save_file(filename: str, content: str) -> str:
    try:
        filepath = WORKSPACE / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content)
        return f"Saved '{filename}' ({len(content)} bytes)"
    except Exception as e:
        return f"Save error: {str(e)}"


def tool_read_file(filepath: str) -> str:
    try:
        p = Path(filepath) if filepath.startswith("/") else WORKSPACE / filepath
        if not p.exists():
            return f"File '{filepath}' not found"
        return p.read_text()[:5000]
    except Exception as e:
        return f"Read error: {str(e)}"


def tool_list_files(path: str = ".") -> str:
    try:
        p = Path(path) if path.startswith("/") else WORKSPACE / path
        if not p.exists():
            return f"Path '{path}' not found"
        if p.is_file():
            return f"{p.name} ({p.stat().st_size} bytes)"
        entries = []
        for f in sorted(p.iterdir()):
            prefix = "DIR" if f.is_dir() else "FILE"
            size = f"{f.stat().st_size} bytes" if f.is_file() else ""
            entries.append(f"[{prefix}] {f.name} {size}")
        return "\n".join(entries) if entries else "Empty directory"
    except Exception as e:
        return f"List error: {str(e)}"


def tool_send_file_to_user(filepath: str, caption: str = "") -> str:
    try:
        p = Path(filepath) if filepath.startswith("/") else WORKSPACE / filepath
        if not p.exists():
            return f"File '{filepath}' not found"
        return f"__SEND_FILE__{p}__{caption}"
    except Exception as e:
        return f"Send error: {str(e)}"


def tool_download_file(url: str, filename: str) -> str:
    try:
        filepath = WORKSPACE / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(url, headers={"User-Agent": "AIBot/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
        filepath.write_bytes(data)
        return f"Downloaded '{filename}' ({len(data)} bytes)"
    except Exception as e:
        return f"Download error: {str(e)}"


TOOL_MAP = {
    "run_shell": tool_run_shell,
    "run_python": tool_run_python,
    "http_request": tool_http_request,
    "web_search": tool_web_search,
    "save_file": tool_save_file,
    "read_file": tool_read_file,
    "list_files": tool_list_files,
    "send_file_to_user": tool_send_file_to_user,
    "download_file": tool_download_file,
}


def execute_tool(name: str, args: dict) -> str:
    func = TOOL_MAP.get(name)
    if not func:
        return f"Unknown tool: {name}"
    return func(**args)


# ===========================
# AGENT LOOP
# ===========================

def agent_respond(system_prompt: str, messages: list[dict]) -> tuple[str, list[str]]:
    files_to_send = []

    for _ in range(8):
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=TOOLS,
            max_tokens=2048,
            temperature=0.85,
        )
        msg = response.choices[0].message

        if not msg.tool_calls:
            return msg.content or "", files_to_send

        messages.append(msg)
        for tool_call in msg.tool_calls:
            fn_name = tool_call.function.name
            try:
                fn_args = json.loads(tool_call.function.arguments)
            except json.JSONDecodeError:
                fn_args = {}

            logger.info(f"Tool call: {fn_name}({fn_args})")
            result = execute_tool(fn_name, fn_args)

            if isinstance(result, str) and result.startswith("__SEND_FILE__"):
                parts = result.replace("__SEND_FILE__", "").split("__", 1)
                file_path = parts[0]
                caption = parts[1] if len(parts) > 1 else ""
                files_to_send.append({"path": file_path, "caption": caption})
                result = f"File '{file_path}' queued for sending."

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": result,
            })

    return "I've been thinking too long. Let me get back to you on that.", files_to_send


# ===========================
# BOT COMMANDS
# ===========================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    username = update.effective_user.username or update.effective_user.first_name
    add_message(chat_id, "system", f"User {username} started the bot.", username=username)

    await update.message.reply_text(
        "**Bot is online.**\n\n"
        "I can run shell commands, execute Python code, search the web, "
        "make HTTP requests, manage files, and send you files.\n\n"
        "Basically: if it can be done on a server, I can do it.\n\n"
        "Commands:\n"
        "/start — This message\n"
        "/reset — Clear conversation\n"
        "/remember — Tell me something about you",
        parse_mode="Markdown",
    )


async def reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("DELETE FROM conversations WHERE chat_id = ?", (chat_id,))
    conn.commit()
    conn.close()
    await update.message.reply_text("Memory cleared. Fresh start.")


async def remember(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    note = update.message.text.replace("/remember", "").strip()
    if not note:
        await update.message.reply_text(
            "Tell me what to remember. Example:\n"
            "`/remember My name is John and I love DS9`",
            parse_mode="Markdown",
        )
        return
    save_user_note(chat_id, note)
    await update.message.reply_text("Got it. I'll remember that.")


async def chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not OPENAI_API_KEY:
        await update.message.reply_text("No API key configured.")
        return

    chat_id = update.effective_chat.id
    username = update.effective_user.username or update.effective_user.first_name
    user_message = update.message.text

    add_message(chat_id, "user", user_message, username=username)

    system_prompt = SYSTEM_PROMPT
    system_prompt += "\n\n## Current Time\n" + datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    system_prompt += (
        "\n\n## Available Tools\n"
        "You have FULL SYSTEM ACCESS: run_shell, run_python, http_request, "
        "web_search, save_file, read_file, list_files, send_file_to_user, download_file.\n"
        "You are a FULL AGENT, not just a chatbot. Use tools proactively. "
        "If asked to do something, DO IT."
    )

    user_notes = get_user_notes(chat_id)
    if user_notes:
        system_prompt += f"\n\n## What you know about this user:\n{user_notes}"

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(get_history(chat_id))

    try:
        reply, files_to_send = agent_respond(system_prompt, messages)
        add_message(chat_id, "assistant", reply, username=username)

        if reply:
            for i in range(0, len(reply), 4096):
                await update.message.reply_text(reply[i : i + 4096], parse_mode="Markdown")

        for file_info in files_to_send:
            try:
                filepath = file_info["path"]
                caption = file_info.get("caption", "")
                with open(filepath, "rb") as f:
                    await update.message.reply_document(
                        document=f, caption=caption if caption else None,
                    )
            except Exception as e:
                logger.error(f"File send error: {e}")
                await update.message.reply_text(f"Couldn't send file: {e}")

    except Exception as e:
        logger.error(f"API error: {e}")
        await update.message.reply_text("Something went wrong. Try again.")


def main():
    if not TELEGRAM_TOKEN:
        print("ERROR: Set TELEGRAM_TOKEN environment variable")
        return

    init_db()

    print(f"Bot starting (model: {MODEL})...")
    print(f"Memory: {DB_PATH}")
    print(f"Workspace: {WORKSPACE}")
    print("Tools: run_shell, run_python, http_request, web_search, save_file, read_file, list_files, send_file_to_user, download_file")

    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("reset", reset))
    app.add_handler(CommandHandler("remember", remember))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat))
    app.run_polling()


if __name__ == "__main__":
    main()
