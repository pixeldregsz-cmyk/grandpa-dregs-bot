#!/bin/bash
# Grandpa Dregs — One-Click Deploy Script
# Run this to deploy your bot to Fly.io

set -e

echo ""
echo "========================================="
echo "  Grandpa Dregs — Fly.io Deploy Script"
echo "========================================="
echo ""

# Get app name
read -p "Enter your Fly.io app name (e.g., my-ai-bot): " APP_NAME
if [ -z "$APP_NAME" ]; then
    echo "App name is required. Exiting."
    exit 1
fi

# Get Telegram token
read -p "Enter your Telegram bot token: " TELEGRAM_TOKEN
if [ -z "$TELEGRAM_TOKEN" ]; then
    echo "Telegram token is required. Exiting."
    exit 1
fi

echo ""
echo "Step 1: Updating fly.toml..."
sed -i.bak "s/app = 'grandpa-dregs'/app = '${APP_NAME}'/" fly.toml
rm -f fly.toml.bak

echo "Step 2: Creating Fly.io app..."
flyctl apps create "$APP_NAME" --org personal 2>/dev/null || echo "(App may already exist, continuing...)"

echo "Step 3: Creating persistent storage volume (1GB, free)..."
flyctl volumes create bot_memory --region iad --size 1 --yes -a "$APP_NAME" 2>/dev/null || echo "(Volume may already exist, continuing...)"

echo "Step 4: Setting Telegram token as secret..."
flyctl secrets set TELEGRAM_TOKEN="$TELEGRAM_TOKEN" -a "$APP_NAME"

echo "Step 5: Deploying..."
flyctl deploy -a "$APP_NAME"

echo ""
echo "========================================="
echo "  DEPLOYED!"
echo "========================================="
echo ""
echo "  App:     $APP_NAME"
echo "  URL:     https://${APP_NAME}.fly.dev"
echo "  Status:  flyctl status -a $APP_NAME"
echo "  Logs:    flyctl logs -a $APP_NAME"
echo ""
echo "  Open Telegram and message your bot!"
echo ""
