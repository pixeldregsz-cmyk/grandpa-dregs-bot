# Grandpa Dregs — AI Telegram Bot

A fully autonomous AI-powered Telegram bot with a unique personality, persistent memory, full server access, and 24/7 hosting on Fly.io's free tier.

**Built entirely from an iPhone. No laptop needed.**

## What You Get

- AI-powered Telegram bot with customizable personality
- Persistent memory across reboots (SQLite)
- Full server access: shell commands, Python code, web search, HTTP requests, file management
- 24/7 hosting on Fly.io free tier — $0/month
- Send files to users via Telegram

## Quick Start

### 1. Create a Telegram Bot

1. Open Telegram, search for **@BotFather**
2. Send `/newbot`
3. Choose a name and username (must end in "bot")
4. Copy the bot token

### 2. Set Up Fly.io

1. Sign up at [fly.io](https://fly.io) (free, card for verification only)
2. Install the Fly CLI:
```bash
curl -L https://fly.io/install.sh | sh
```
3. Log in:
```bash
flyctl auth login
```

### 3. Configure & Deploy

1. Edit `soul.md` — this is your bot's personality. Make it yours.
2. Edit `fly.toml` — change `app = 'your-bot-name'` to your app name.
3. Run the deploy script:
```bash
chmod +x deploy.sh
./deploy.sh
```

The script will:
- Create your Fly.io app
- Create a persistent storage volume
- Set your Telegram token as a secret
- Deploy the bot

### 4. Test It

Open Telegram and message your bot. Try `/start`.

## Commands

| Command | What It Does |
|---|---|
| `/start` | Welcome message |
| `/reset` | Clear conversation history |
| `/remember <text>` | Tell the bot something to remember about you |

## What the Bot Can Do

| Tool | Capability |
|---|---|
| `run_shell` | Execute any shell command |
| `run_python` | Run Python code |
| `http_request` | Make HTTP requests (GET/POST/PUT/DELETE) |
| `web_search` | Search the web via DuckDuckGo |
| `save_file` | Save files to workspace |
| `read_file` | Read any file |
| `list_files` | Browse directories |
| `download_file` | Download files from URLs |
| `send_file_to_user` | Send files via Telegram |

## Customization

### Personality

Edit `soul.md` to change your bot's entire personality. Be specific — the more detail, the better the responses.

### Model

The bot uses OpenGateway (free AI API). To use a different API, set these environment variables in `fly.toml`:

```toml
[env]
  OPENAI_BASE_URL = "https://your-api-url/v1"
  MODEL = "your-model-name"
```

And set the API key:
```bash
flyctl secrets set OPENAI_API_KEY="your-key" -a your-app-name
```

## Managing Your Bot

```bash
# Check status
flyctl status -a your-app-name

# View logs
flyctl logs -a your-app-name

# Restart
flyctl apps restart your-app-name

# Deploy updates
flyctl deploy -a your-app-name

# Delete everything
flyctl apps destroy your-app-name
```

## File Structure

```
├── bot.py           # Main bot code
├── soul.md          # Bot personality (EDIT THIS)
├── requirements.txt # Python dependencies
├── Dockerfile       # Docker build config
├── fly.toml         # Fly.io config (EDIT APP NAME)
├── deploy.sh        # One-click deploy script
└── README.md        # This file
```

## Free Tier Limits

| Resource | Free Limit | Usage |
|---|---|---|
| AI API | OpenGateway (free) | Unlimited |
| Fly.io VMs | 3x shared-cpu-1x | 1 used |
| Fly.io Storage | 3GB volume | 1GB used |
| Fly.io Data | 160GB outbound | Minimal |

## Credits

Built with love and stubbornness. Powered by OpenGateway AI.

---

*Grandpa Dregs: "I've seen civilizations rise and fall. I've debugged systems that would make your head spin. And I've got opinions about ALL of it."*
